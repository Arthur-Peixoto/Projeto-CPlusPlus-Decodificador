int armazenar(char, char, char, char);
unsigned char primeiro(int);
unsigned char segundo(int);
unsigned char terceiro(int);
unsigned char quarto(int);
int soma(int, int);
int mult(int, int);
