unsigned int ligarbit(unsigned int, int);
unsigned int Desligarbits(unsigned int, int);
bool Testarbits(unsigned int, int); 
unsigned long long codificar(unsigned int);
unsigned int decodificar(unsigned long long);

